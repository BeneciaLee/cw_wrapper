#include <stdint.h>
#include <stdlib.h>
#include "hal.h"
#include "simpleserial.h"

uint8_t mk[16];

uint8_t key_schedule(uint8_t* k, uint8_t len)
{
    // TODO
    for(int i = 0; i < 16; i++)
	    mk[i] = k[i];
    //

    return 0x00;
}

uint8_t crypto_main(uint8_t* text_in_buf, uint8_t len)
{
	trigger_high();

	// TODO
    for(int i = 0; i < 16; i++)
        text_in_buf[i] = text_in_buf[i] ^ mk[i];
    //

	trigger_low();

	simpleserial_put('r', 16, text_in_buf);
	return 0x00;
}

uint8_t reset(uint8_t* x, uint8_t len)
{
    // TODO
	for(int i = 0; i < 16; i++)
	    mk[i] = 0x00;
    //

	return 0x00;
}

int main(void)
{
    platform_init();
	init_uart();
	trigger_setup();

 	/* Uncomment this to get a HELLO message for debug */
	/*
	putch('h');
	putch('e');
	putch('l');
	putch('l');
	putch('o');
	putch('\n');
	*/

	simpleserial_init();  // 'v': check_version, 'y': ss_num_commands, 'w': ss_get_commands
	simpleserial_addcmd('p', 16, crypto_main);
	simpleserial_addcmd('k', 16, key_schedule);
	simpleserial_addcmd('x', 0, reset);
	while(1)
		simpleserial_get();
}
